import json
from datetime import datetime
from src.utils.plivo_helper import get_plivo_client
from src.utils.dynamodb_helper import get_dynamodb_table
from src.models.masking_session import MaskingSession


def handler(event, context):
    try:
        # Parse the Plivo webhook payload
        body = json.loads(event["body"])
        # from_number = body["From"]
        to_number = body["To"]
        text = body["Text"]

        # Check if this is an SMS to a burner number
        session_table = get_dynamodb_table("MaskingSessions")
        session_item = session_table.query(
            IndexName="burner_number-index",
            KeyConditionExpression="burner_number = :burner_number",
            ExpressionAttributeValues={":burner_number": to_number},
        )

        if session_item["Items"]:
            # This is an SMS from a recruiter to a job seeker
            session = MaskingSession.from_dict(session_item["Items"][0])
            session.last_connected_at = datetime.now().isoformat()
            session_table.put_item(Item=session.to_dict())

            # Forward the SMS to the job seeker
            plivo_client = get_plivo_client()
            plivo_client.messages.create(
                src=session.virtual_number, dst=session.job_seeker_number, text=text
            )
        else:
            # Check if this is an SMS to a virtual number
            session_item = session_table.query(
                IndexName="virtual_number-index",
                KeyConditionExpression="virtual_number = :virtual_number",
                ExpressionAttributeValues={":virtual_number": to_number},
            )

            if session_item["Items"]:
                # This is an SMS from a job seeker to a recruiter
                session = MaskingSession.from_dict(session_item["Items"][0])
                session.last_connected_at = datetime.now().isoformat()
                session_table.put_item(Item=session.to_dict())

                # Forward the SMS to the recruiter
                plivo_client = get_plivo_client()
                plivo_client.messages.create(
                    src=session.burner_number, dst=session.recruiter_number, text=text
                )
            else:
                # This is an invalid SMS
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "Invalid number"}),
                }

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "SMS processed successfully"}),
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
