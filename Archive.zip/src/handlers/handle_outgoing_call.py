import json
from datetime import datetime
from src.utils.dynamodb_helper import get_dynamodb_table
from src.models.masking_session import MaskingSession


def handler(event, context):
    try:
        # Parse the Plivo webhook payload
        body = json.loads(event["body"])
        from_number = body["From"]
        # to_number = body["To"]

        # Check if this is a call from a virtual number
        session_table = get_dynamodb_table("MaskingSessions")
        session_item = session_table.query(
            IndexName="virtual_number-index",
            KeyConditionExpression="virtual_number = :virtual_number",
            ExpressionAttributeValues={":virtual_number": from_number},
        )

        if session_item["Items"]:
            # This is a call from a job seeker to a recruiter
            session = MaskingSession.from_dict(session_item["Items"][0])
            session.last_connected_at = datetime.now().isoformat()
            session_table.put_item(Item=session.to_dict())

            xml = f"""
            <Response>
                <Dial callerId="{session.burner_number}">
                    <Number>{session.recruiter_number}</Number>
                </Dial>
            </Response>
            """
        else:
            # This is an invalid call
            xml = """
            <Response>
                <Speak>We're sorry, but this number is not recognized. Please check the number and try again.</Speak>
            </Response>
            """

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/xml"},
            "body": xml,
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
