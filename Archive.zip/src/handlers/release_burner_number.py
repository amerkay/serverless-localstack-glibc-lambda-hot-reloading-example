import json
from src.utils.plivo_helper import get_plivo_client
from src.utils.dynamodb_helper import get_dynamodb_table

# from src.models.burner_to_real import BurnerToReal


def handler(event, context):
    try:
        # Parse the request body
        body = json.loads(event["body"])
        burner_number = body["burner_number"]

        # Get the BurnerToReal entry
        table = get_dynamodb_table("BurnerToReal")
        burner_item = table.get_item(Key={"burner_number": burner_number})

        if "Item" not in burner_item:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "Burner number not found"}),
            }

        # Delete the BurnerToReal entry
        table.delete_item(Key={"burner_number": burner_number})

        # Release the Plivo number
        plivo_client = get_plivo_client()
        plivo_client.numbers.unrent(burner_number)

        # Delete associated MaskingSessions
        session_table = get_dynamodb_table("MaskingSessions")
        sessions = session_table.query(
            IndexName="burner_number-index",
            KeyConditionExpression="burner_number = :burner_number",
            ExpressionAttributeValues={":burner_number": burner_number},
        )

        for session in sessions["Items"]:
            session_table.delete_item(Key={"session_id": session["session_id"]})

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Burner number released successfully"}),
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
