import json
import uuid
from datetime import datetime, timedelta
from src.utils.plivo_helper import get_plivo_client
from src.utils.dynamodb_helper import get_dynamodb_table

# from src.models.burner_to_real import BurnerToReal
from src.models.masking_session import MaskingSession


def handler(event, context):
    try:
        # Parse the Plivo webhook payload
        body = json.loads(event["body"])
        from_number = body["From"]
        to_number = body["To"]

        # Check if the call is to a burner number
        burner_table = get_dynamodb_table("BurnerToReal")
        burner_item = burner_table.get_item(Key={"burner_number": to_number})

        if "Item" not in burner_item:
            # The call is from a recruiter to the burner number
            session_table = get_dynamodb_table("MaskingSessions")
            session_item = session_table.query(
                IndexName="burner_number-index",
                KeyConditionExpression="burner_number = :burner_number",
                ExpressionAttributeValues={":burner_number": to_number},
            )

            if not session_item["Items"]:
                # Create a new masking session
                plivo_client = get_plivo_client()
                virtual_numbers = plivo_client.numbers.list(
                    country_iso="US", type="local"
                )
                if not virtual_numbers:
                    return {
                        "statusCode": 400,
                        "body": json.dumps({"error": "No available virtual numbers"}),
                    }

                virtual_number = virtual_numbers[0].number

                session = MaskingSession(
                    session_id=str(uuid.uuid4()),
                    job_seeker_number=burner_item["Item"]["real_number"],
                    recruiter_number=from_number,
                    virtual_number=virtual_number,
                    burner_number=to_number,
                    expiry_date=(datetime.now() + timedelta(days=30)).isoformat(),
                    last_connected_at=datetime.now().isoformat(),
                )
                session_table.put_item(Item=session.to_dict())
            else:
                session = MaskingSession.from_dict(session_item["Items"][0])
                session.last_connected_at = datetime.now().isoformat()
                session_table.put_item(Item=session.to_dict())

            # Generate Plivo XML to connect the call
            xml = f"""
            <Response>
                <Dial callerId="{to_number}">
                    <Number>{session.job_seeker_number}</Number>
                </Dial>
            </Response>
            """
        else:
            # The call is from a job seeker to their burner number
            # In this case, we should provide an menu to the job seeker
            xml = """
            <Response>
                <GetDigits action="/handle-burner-menu" method="POST" numDigits="1" timeout="10">
                    <Speak>Welcome to your Stellar Nurse b`urner number menu.
                    Press 1 to release this number, or press 2 to hear your recent calls.</Speak>
                </GetDigits>
            </Response>
            """

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/xml"},
            "body": xml,
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
