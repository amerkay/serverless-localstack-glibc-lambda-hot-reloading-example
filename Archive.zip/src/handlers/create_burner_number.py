# For hot-reload
# awslocal lambda create-function --function-name create_burner_number --code S3Bucket="hot-reload",S3Key="${PWD}" --handler src/handlers/create_burner_number.handler --runtime python3.10 --role arn:aws:iam::000000000000:role/lambda-ex

import sys
import os
import subprocess

# # import glob
# # sys.path.insert(0, glob.glob(".venv/lib/python*/site-packages")[0])

import plivo


def handler(event, context):
    print("Python version:", sys.version)
    print("Current directory:", os.getcwd())
    print("Directory contents:", os.listdir())
    print("PYTHONPATH:", os.environ.get("PYTHONPATH"))

    # List installed packages
    print("Installed packages:")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "list"], capture_output=True, text=True
    )
    print(result.stdout)

    try:

        print("Plivo version:", plivo.__version__)
        return {
            "statusCode": 200,
            "body": {
                # "python_version": sys.version,
                # "current_directory": os.getcwd(),
                # "directory_contents": os.listdir(),
                # "python_path": os.environ.get("PYTHONPATH"),
                "plivo_version": plivo.__version__,
                "installed_packages": result.stdout,
            },
        }
    except ImportError as e:
        print("Failed to import plivo:", str(e))
        return {"statusCode": 500, "error": str(e)}


# import json
# from datetime import datetime, timedelta
# from src.utils.plivo_helper import get_plivo_client
# from src.utils.dynamodb_helper import get_dynamodb_table
# from src.models.burner_to_real import BurnerToReal


# def handler(event, context):
#     try:
#         # Parse the request body
#         body = json.loads(event["body"])
#         real_number = body["real_number"]

#         # Get a Plivo number for the burner
#         plivo_client = get_plivo_client()
#         response = plivo_client.numbers.search(country_iso="US", type="local")

#         numbers = response.objects

#         if not numbers:
#             return {
#                 "statusCode": 400,
#                 "body": json.dumps({"error": "No available Plivo numbers"}),
#             }
#         else:
#             # Convert the response objects to a JSON-serializable format
#             serializable_numbers = response_object_to_dict(numbers)
#             return {
#                 "statusCode": 200,
#                 "body": json.dumps({"first_number": serializable_numbers[0]}),
#             }

#         # burner_number = numbers[0].number

#         # # Create a BurnerToReal entry
#         # burner_to_real = BurnerToReal(
#         #     burner_number=burner_number,
#         #     real_number=real_number,
#         #     expiry_date=(datetime.now() + timedelta(days=21)).isoformat(),
#         # )

#         # # Save to DynamoDB
#         # table = get_dynamodb_table("BurnerToReal")
#         # table.put_item(Item=burner_to_real.to_dict())

#         # return {"statusCode": 200, "body": json.dumps({"burner_number": burner_number})}
#     except Exception as e:
#         return {"statusCode": 500, "body": json.dumps({"error": str(e)})}


# def response_object_to_dict(obj):
#     if isinstance(obj, list):
#         return [response_object_to_dict(item) for item in obj]
#     elif hasattr(obj, "__dict__"):
#         return {
#             key: response_object_to_dict(value) for key, value in obj.__dict__.items()
#         }
#     else:
#         return obj
